<?php 
    include("header.php");
    if(isset($_SESSION["email"])==null)
    {
    header("location:adminlogin.php");
    }
    else
    {

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
        if(isset($_GET["addLocation"]))
        {
            include("addlocation.php");
        }
        else if(isset($_GET["addSpec"]))
        {
            include("addspeci.php");
        }

        else if(isset($_GET["Adddoctor"]))
        {
            include("adddoctor.php");
        }
    ?>
</body>
</html>
<?php } ?>