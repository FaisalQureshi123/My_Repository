<?php 
    include("connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>
<body>
    <div class="container">
        <h1>Add New Doctor</h1>
        <form action="" method="POST" enctype="multipart/form-data">
            <table class="table">
                <tr>
                    <td>Name </td>
                    <td><input type="text" name="txtname" id="" class="form-control"></td>
                </tr>
                <tr>
                    <td>Email </td>
                    <td><input type="email" name="txtemail" id="" class="form-control"></td>
                </tr>
                <tr>
                    <td>Password </td>
                    <td><input type="password" name="txtpassword" id="" class="form-control"></td>
                </tr>
                <tr>
                    <td>Gender </td>
                    <td>
                        <select name="txtgender" id="" class="form-control">
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Location </td>
                    <td>
                        <select name="txtloc" id="" class="form-control">
                            <?php 
                                $l = mysqli_query($con,"select * from locationtb");
                                while($row = mysqli_fetch_array($l))
                                {

                                
                            ?>
                            <option value="<?php echo $row[0] ?>"><?php echo $row[1] ?></option>

                            <?php } ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Specilization </td>
                    <td>
                        <select name="txtspec" id="" class="form-control">
                        <?php 
                                $l = mysqli_query($con,"select * from specializationtb");
                                while($row = mysqli_fetch_array($l))
                                {

                                
                            ?>
                            <option value="<?php echo $row[0] ?>"><?php echo $row[1] ?></option>

                            <?php } ?>
                            
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Image </td>
                    <td><input type="file" name="filename" id="" class="form-control"></td>
                </tr>
                <tr>
                    <td>Expernce</td>
                    <td><input type="text" name="txtexp" id="" class="form-control"></td>
                </tr>
                <tr>
                    <td>Availibilty</td>
                    <td><input type="text" name="txtav" id="" class="form-control"></td>
                </tr>
                
                <tr>
                    <td> </td>
                    <td><input type="submit" name="btn" id="" class="btn btn-success"></td>
                </tr>
                
            </table>
        </form>

        <?php 
            if(isset($_POST["btn"]))
            {
                $name       = $_POST["txtname"];
                $email      = $_POST["txtemail"];
                $password   = $_POST["txtpassword"];
                $gender     = $_POST["txtgender"];
                $location   = $_POST["txtloc"];
                $spec       = $_POST["txtspec"];
                $image      = $_FILES["filename"]["name"]; //image name
                $imageloc   = $_FILES["filename"]["tmp_name"]; // image location
                $experence  = $_POST["txtexp"];
                $avilibilty = $_POST["txtav"];

                move_uploaded_file($imageloc,"doctorimage/".$image);
                
                $q = mysqli_query($con,"INSERT INTO `doctortb`(`dname`, `email`, `password`, `gender`, `locID`, `spID`, `image`, `experience`, `availibilty`) 
                VALUES ('$name','$email','$password','$gender','$location','$spec','$image','$experence','$avilibilty')");
                if($q>0)
                {
                    echo '<script>swal("Data Save!", "You clicked the button!", "success");</script>';
                }
                else
                {
                    echo "<h1>Not Save</h1>";
                }
            }
        ?>
        
    </div>
</body>
</html>