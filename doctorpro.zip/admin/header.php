<?php 
  include("connection.php");
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>
<body>
    <div class="container">

   
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Doctor Care</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Location<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="dashboard.php?addLocation">Add Location</a></li>
          <li><a href="#">View Location</a></li>
        </ul>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Spec<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="dashboard.php?addSpec">Add Spec</a></li>
          <li><a href="#">View Spec</a></li>
        </ul>
      </li>
      
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Doctor<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="dashboard.php?Adddoctor">Add Doctor</a></li>
          <li><a href="#">View Doctor</a></li>
          
        </ul>
      </li>
  
      
      <li><a href="#">About</a></li>
      <li><a href="#">Contact</a></li>
      
    </ul>
    
    <?php 
      if(isset($_SESSION["email"])!=null)
      {
        echo '
        <ul class="nav navbar-nav navbar-right">
      <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logoutss</a></li>
    </ul>
        ';
      }
      else
      {
          echo '
          <ul class="nav navbar-nav navbar-right">
      <li><a href="adminlogin.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
          ';
      }
    ?>
    
    
  </div>
</nav> 




</div>
</body>
</html>

