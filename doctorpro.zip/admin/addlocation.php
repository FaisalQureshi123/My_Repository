<?php 
    include("connection.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

</head>
<body>
    <div class="container">
        <h1>Add New Location</h1>
        <form action="" method="POST">
            <table class="table">
                <tr>
                    <td>Name </td>
                    <td><input type="text" name="txtname" id="" class="form-control"></td>
                </tr>
                <tr>
                    <td> </td>
                    <td><input type="submit" name="btn" id="" class="btn btn-success"></td>
                </tr>
                
            </table>
        </form>
        <?php 
            if(isset($_POST["btn"]))
            {
                $name = $_POST["txtname"];
                $q = mysqli_query($con,"insert into locationtb (lname) values ('$name')");
                if($q>0)
                {
                    echo '<script>swal("Data Save!", "You clicked the button!", "success");</script>';
                }
                else
                {
                    echo "<h1>Not Save</h1>";
                }
            }
        ?>

    </div>
</body>
</html>