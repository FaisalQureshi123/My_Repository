<?php 
include("connection.php");
session_start();
if(isset($_SESSION["email"])!=null)
{
  header("location:dashboard.php");
}
else
{


?>
<link rel="stylesheet" href="style.css">
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->

    <!-- Icon -->
    <div class="fadeIn first">
      <h1>Admin Login</h1>
    </div>

    <!-- Login Form -->
    <form action="" method="POST">
      <input type="text" id="login" class="fadeIn second" name="Email" placeholder="Email">
      <input type="text" id="password" class="fadeIn third" name="password" placeholder="password">
      <input type="submit" class="fadeIn fourth" value="Log In" name="btn">
    </form>
    <?php 
        if(isset($_POST["btn"]))
        {
          $email = $_POST["Email"];
          $pass = $_POST["password"];
          
          $login = mysqli_query($con,"select * from admin where Email='$email' AND Password='$pass'");
          $check = mysqli_num_rows($login);
          $a = mysqli_fetch_array($login);
          if($check>0)
          {
            $_SESSION["email"] = $a[1];
            echo "<script>window.location.href='http://localhost:81/doctorpro/admin/dashboard.php'</script>";
          }
          else
          {
            echo "<h1>Login Failed</h1>";
          }
        }
    ?>
  </div>
</div>
<?php } ?>