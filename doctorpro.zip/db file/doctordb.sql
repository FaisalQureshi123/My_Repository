-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 09, 2022 at 05:55 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doctordb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `Email`, `Password`) VALUES
(1, 'admin@gmail.com', '123');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `aid` int(11) NOT NULL,
  `patID` int(11) NOT NULL,
  `docID` int(11) NOT NULL,
  `pname` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `query` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`aid`, `patID`, `docID`, `pname`, `contact`, `query`) VALUES
(1, 1, 1, 'Qadeer', '030312345669', 'I have a problem in my heart');

-- --------------------------------------------------------

--
-- Table structure for table `doctortb`
--

CREATE TABLE `doctortb` (
  `did` int(11) NOT NULL,
  `dname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `locID` int(11) NOT NULL,
  `spID` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `experience` varchar(255) NOT NULL,
  `availibilty` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctortb`
--

INSERT INTO `doctortb` (`did`, `dname`, `email`, `password`, `gender`, `locID`, `spID`, `image`, `experience`, `availibilty`) VALUES
(1, 'Mudassir Qureshi', 'm@gmail.com', '456', 'Male', 2, 1, 'ab.jpg', '8 years', 'MWF');

-- --------------------------------------------------------

--
-- Table structure for table `locationtb`
--

CREATE TABLE `locationtb` (
  `lid` int(11) NOT NULL,
  `lname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `locationtb`
--

INSERT INTO `locationtb` (`lid`, `lname`) VALUES
(1, 'Karachi'),
(2, 'Larkana'),
(3, 'Islamabad'),
(4, 'Lahore');

-- --------------------------------------------------------

--
-- Table structure for table `patienttb`
--

CREATE TABLE `patienttb` (
  `pid` int(11) NOT NULL,
  `pname` varchar(2255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patienttb`
--

INSERT INTO `patienttb` (`pid`, `pname`, `email`, `password`) VALUES
(1, 'Qadeer Buksh', 'q@gmail.com', '789');

-- --------------------------------------------------------

--
-- Table structure for table `specializationtb`
--

CREATE TABLE `specializationtb` (
  `sid` int(11) NOT NULL,
  `sname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `specializationtb`
--

INSERT INTO `specializationtb` (`sid`, `sname`) VALUES
(1, 'Heart Surgeon'),
(2, 'Eye specialist');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`aid`),
  ADD KEY `patID` (`patID`),
  ADD KEY `docID` (`docID`);

--
-- Indexes for table `doctortb`
--
ALTER TABLE `doctortb`
  ADD PRIMARY KEY (`did`),
  ADD KEY `locID` (`locID`),
  ADD KEY `spID` (`spID`);

--
-- Indexes for table `locationtb`
--
ALTER TABLE `locationtb`
  ADD PRIMARY KEY (`lid`);

--
-- Indexes for table `patienttb`
--
ALTER TABLE `patienttb`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `specializationtb`
--
ALTER TABLE `specializationtb`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `doctortb`
--
ALTER TABLE `doctortb`
  MODIFY `did` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `locationtb`
--
ALTER TABLE `locationtb`
  MODIFY `lid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `patienttb`
--
ALTER TABLE `patienttb`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `specializationtb`
--
ALTER TABLE `specializationtb`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`docID`) REFERENCES `doctortb` (`did`),
  ADD CONSTRAINT `appointment_ibfk_2` FOREIGN KEY (`patID`) REFERENCES `patienttb` (`pid`);

--
-- Constraints for table `doctortb`
--
ALTER TABLE `doctortb`
  ADD CONSTRAINT `doctortb_ibfk_1` FOREIGN KEY (`locID`) REFERENCES `locationtb` (`lid`),
  ADD CONSTRAINT `doctortb_ibfk_2` FOREIGN KEY (`spID`) REFERENCES `specializationtb` (`sid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
