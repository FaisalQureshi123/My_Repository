<?php 
    include("header.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .box
        {
            border: 1px solid;
            text-align: center;
            height: 200px;
            background-color: gray;
            color: white;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-lg-4">
                <div class="box">
                    <h3>( Admin Login )</h3>
                    <a href="admin/adminlogin.php" class="btn btn-danger">Admin Login</a>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="box">
                <h3>( Doctor Login )</h3>
                    <a href="" class="btn btn-danger">Doctor Login</a>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="box">
                <h3>( Patient Login )</h3>
                    <a href="" class="btn btn-danger">Patient Login</a>
                </div>
            </div>
            

        </div>
    </div>
</body>
</html>