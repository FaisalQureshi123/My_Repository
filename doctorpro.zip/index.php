<?php 
    include("header.php");
      include("connection.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
      .thumbnail
      {
        padding: 10px;
        border: 0.5px solid;
      }
      .img
      {
        width: 350px;
        height: 350px;
      }
    </style>
</head>
<body>
    <div class="container">
    <h2>Doctor Care Website</h2>
  
  <div class="row">
   
  <?php 
    $fetchdoc = mysqli_query($con,"select * from doctortb");
    while($row = mysqli_fetch_array($fetchdoc))
    {

  
  ?>
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="" target="_blank">
          <img src="admin/doctorimage/<?php echo $row[7] ?>" alt="Nature" style="width:350px ; height:350px ;">
          <div class="caption">
            <p style="font-weight: bolder; font-size: 20px;">
                Name : <?php  echo $row[1]?><br>
                Experence : <?php  echo $row[8]?><br>
                Availabilty : <?php  echo $row[9]?><br>
                <a href="" class="btn btn-primary">Book Appointment</a>
            </p>
          </div>
        </a>
      </div>
    </div>
   <?php } ?>
  </div>
    </div>
</body>
</html>